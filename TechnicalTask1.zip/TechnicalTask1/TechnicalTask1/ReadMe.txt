﻿Technology:
Visual Studio 2019
Nunit Selenium C#

Deliverables:
1. structure of the project:
Dependencies - downloaded and installed from nuget package manager as required.
PageObjects folder - contains page objects for tests
TestScripts folder - contains test cases
BaseTest class - contains onetime setup for the test automation
2.HTMl Reports - using extent reports:
Extentreport folder - contains HTML report of the test cases execution[Screenshot of the report attached].
3.Use od Config File:
ConfigFile folder - contains App.config from where values can be fetched[used in 'Configtest' Test].
4.Use of page Object Model:
PageObjects folder - contains page objects for tests[Used in 'Test1' test]
5.Video of the tests execution - link in the zip folder.